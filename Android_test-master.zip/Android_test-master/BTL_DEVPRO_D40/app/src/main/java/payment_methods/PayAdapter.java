package payment_methods;

public class PayAdapter {
}
