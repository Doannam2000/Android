package projects;

public class ProjectAdapter {
}
