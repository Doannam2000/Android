package recruitment;

public class RecruitmentFragment {
}
