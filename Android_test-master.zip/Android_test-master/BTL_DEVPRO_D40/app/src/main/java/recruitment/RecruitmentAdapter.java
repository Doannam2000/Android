package recruitment;

public class RecruitmentAdapter {
}
