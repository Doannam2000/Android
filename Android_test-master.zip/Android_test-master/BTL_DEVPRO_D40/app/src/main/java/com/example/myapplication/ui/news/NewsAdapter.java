package com.example.myapplication.ui.news;

public class NewsAdapter {
}
