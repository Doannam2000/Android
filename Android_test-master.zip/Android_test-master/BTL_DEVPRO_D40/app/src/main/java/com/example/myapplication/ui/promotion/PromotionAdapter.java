package com.example.myapplication.ui.promotion;

public class PromotionAdapter {
}
