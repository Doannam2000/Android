package com.example.myapplication.ui.contact;

public class ContactAdapter {
}
