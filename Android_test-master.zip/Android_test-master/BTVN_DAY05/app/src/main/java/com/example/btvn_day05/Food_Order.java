package com.example.btvn_day05;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Food_Order extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food__order);
    }
}
