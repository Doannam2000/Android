package com.example.btvn_day05;

public interface Onclick {

    public void onClickName(String name);

}
