package com.example.fragmentdemo;

public interface IonClickFood {
    void onClickName(Food food);
    void onClickImg(Food food);
    void onClickLayout(Food food);
}
